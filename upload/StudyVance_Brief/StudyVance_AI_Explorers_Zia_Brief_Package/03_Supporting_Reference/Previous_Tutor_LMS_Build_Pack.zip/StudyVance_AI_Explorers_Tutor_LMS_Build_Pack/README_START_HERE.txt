STUDYVANCE AI EXPLORERS - TUTOR LMS BUILD PACK

WHAT THIS PACK IS
A manual-build content pack for Tutor LMS Free. It is not a one-click import. It includes the lesson pages, quiz build sheet, course settings guide, learner workbook, tutor-only teacher guide and course thumbnail.

FOLDER GUIDE
00_Tutor_LMS_Build_Guide.docx - step-by-step WordPress/Tutor LMS build instructions and exact topic hierarchy.
01_All_Learner_Lesson_Content.docx - full editable copy of all learner-facing lesson pages.
01_Course_Description.txt - ready-to-paste course description.
html_lessons/ - individual HTML lesson pages. Open a page in a browser, copy the visible content, and paste into the matching Tutor LMS lesson editor.
quizzes/Quiz_Build_Sheet_FOR_MANUAL_ENTRY.docx - 30 questions across 6 quizzes with answer explanations. Enter manually; not an import file.
student/StudyVance_Level_1_Learner_Workbook.pdf - share with learners if using the workbook.
tutor_reference/StudyVance_Level_1_Teacher_Guide_TUTOR_ONLY.pdf - contains answers, assessment notes and parent guidance; do not publish to learner course.
media/StudyVance_AI_Explorers_Course_Thumbnail.jpg - upload to WordPress Media Library and use as the course image.

FAST BUILD
1. Create course “StudyVance AI Academy - Level 1 AI Explorers”.
2. Paste description from 01_Course_Description.txt.
3. Upload the course thumbnail and learner workbook to WordPress Media Library.
4. Create the Welcome topic and its Start Here lesson. Replace [WORKBOOK_LINK] in that lesson with the uploaded workbook's URL or remove the line.
5. Create the six Mission topics in order. Add each topic’s two HTML lesson pages and its five-question quiz.
6. Enter quizzes manually using the quiz build sheet and add each supplied answer explanation. Quiz CSV import/export is documented by Tutor LMS as a Pro add-on, so this pack does not claim to import quizzes into the Free plugin.
7. Keep the final story as a learner portfolio for tutor review; do not configure it as an assignment if you are avoiding Pro features.
8. Test the course with a learner test account before launch.

SAFETY AND TEACHING MODEL
All core activities can be completed using the prepared examples and workbook; no child AI account, paid tool, camera or microphone is required. Live AI use is optional and adult-operated. For ChatGPT interactions with children under 13 in an educational setting, an adult must conduct the interaction. Check current rules for any other tool.

TOPIC ORDER
Welcome, AI Explorer!
Mission 1 - Meet AI
Mission 2 - Ask Better Questions
Mission 3 - Become an AI Detective
Mission 4 - Create Something
Mission 5 - Learn with AI
Mission 6 - Finish and Present

Official Tutor LMS docs:
https://tutorlms.com/docs/course-builder/curriculum/
https://tutorlms.com/docs/quiz-builder/quiz-builder/
https://tutorlms.com/docs/quiz-builder/quiz-export-import/
